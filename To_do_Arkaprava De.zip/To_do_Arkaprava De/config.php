<?php
$connect= mysqli_connect("localhost","root","","to_do") or die("connection failed!");
?>